package com.example.mobile2appevent_trackingapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class EventDetails extends AppCompatActivity {

    EditText titleIN, descriptionIN;
    String id, title, description, date, time;
    Button updateB, deleteB, timeB, dateB;
    String notification;
    int notificationC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);

        // id for buttons
        titleIN = findViewById(R.id.eventTitle);
        descriptionIN = findViewById(R.id.eventDescription);
        dateB = findViewById(R.id.date);
        timeB = findViewById(R.id.time);
        updateB = findViewById(R.id.updateBtn);
        deleteB = findViewById(R.id.deleteBtn);

        //date and time
        dateB.setOnClickListener(view -> selectDate());
        timeB.setOnClickListener(view -> selectTime());

        //disable update button
        titleIN.addTextChangedListener(textWatcher);
        descriptionIN.addTextChangedListener(textWatcher);
        timeB.addTextChangedListener(textWatcher);
        dateB.addTextChangedListener(textWatcher);

        //get data
        getAndSetIntentData();

        //update event button
        updateB.setOnClickListener(view -> {

            MainDatabase db = new MainDatabase(EventDetails.this);
            db.updateData(id,
                    titleIN.getText().toString().trim(),
                    descriptionIN.getText().toString().trim(),
                    dateB.getText().toString().trim(),
                    timeB.getText().toString().trim());
            finish();
        });
        deleteB.setOnClickListener(view -> confirmDialog());

    }

    //makes sure everything is filled
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String date = dateB.getText().toString().trim();
            String time = timeB.getText().toString().trim();
            String title = titleIN.getText().toString().trim();
            String description = descriptionIN.getText().toString().trim();

            updateB.setEnabled(!title.isEmpty() && !description.isEmpty() &&
                    !date.isEmpty() && !time.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    //delete event
    void confirmDialog(){
        AlertDialog.Builder build = new AlertDialog.Builder(this);
        build.setTitle("Delete " + title + "?");
        build.setMessage("You want to delete? " + title + "?");
        build.setPositiveButton("Yes", (dialogInterface, i) -> {
            MainDatabase db = new MainDatabase(EventDetails.this);
            db.deleteOneRow(id);
            finish();
        });
        build.setNegativeButton("No", (dialogInterface, i) -> {

        });
        build.create().show();

    }

    //setting data for the buttons and text

    void getAndSetIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("title") &&
                getIntent().hasExtra("description") && getIntent().hasExtra("date") &&
                getIntent().hasExtra("time")){

            //gets data from intent
            id = getIntent().getStringExtra("id");
            notificationC = Integer.parseInt(id);
            date = getIntent().getStringExtra("date");
            time = getIntent().getStringExtra("time");
            title = getIntent().getStringExtra("title");
            description = getIntent().getStringExtra("description");

            //sets intent data
            dateB.setText(date);
            timeB.setText(time);
            titleIN.setText(title);
            descriptionIN.setText(description);

        }else{
            Toast.makeText(this, "Nothing to update", Toast.LENGTH_SHORT).show();
        }
    }



    //sets date and time

    private void selectTime() {
        Calendar cal = Calendar.getInstance();
        int hr = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        TimePickerDialog PickerDialog = new TimePickerDialog(this, (timePicker, i, i1) -> {
            notification = i + ":" + i1;
            timeB.setText(formatTime(i, i1));
        }, hr, min, false);
        PickerDialog.show();
    }

    private void selectDate() {
        Calendar cal = Calendar.getInstance();
        int Y = cal.get(Calendar.YEAR);
        int M = cal.get(Calendar.MONTH);
        int D = cal.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog PickerDialog = new DatePickerDialog(this, this::onDateSet, Y, M, D);
        PickerDialog.show();
    }

    public String formatTime(int hr, int min) {

        String T;
        String RM;

        if (min / 10 == 0) {
            RM = "0" + min;
        } else {
            RM = "" + min;
        }

        if (hr == 0) {
            time = "12" + ":" + RM + " AM";
        } else if (hr < 12) {
            time = hr + ":" + RM + " AM";
        } else if (hr == 12) {
            time = "12" + ":" + RM + " PM";
        } else {
            int temp = hr - 12;
            time = temp + ":" + RM + " PM";
        }
        return time;
    }

    @SuppressLint("SetTextI18n")
    private void onDateSet(DatePicker datePicker, int year, int month, int day) {
        dateB.setText(String.format("%d-%d-%d", day, month + 1, year));
    }
}