package com.example.mobile2appevent_trackingapp;


import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;




public class CreateEvent extends AppCompatActivity {

    EditText titleIN, descriptionIN;
    Button addB, timeB, dateB;
    String notification;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        // id for buttons
        titleIN = findViewById(R.id.eventTitle);
        descriptionIN = findViewById(R.id.eventDescription);
        dateB = findViewById(R.id.date);
        timeB = findViewById(R.id.time);
        addB = findViewById(R.id.addEvent);

        //date and time
        dateB.setOnClickListener(view -> selectDate());
        timeB.setOnClickListener(view -> selectTime());

        //disable add button
        titleIN.addTextChangedListener(textWatcher);
        descriptionIN.addTextChangedListener(textWatcher);
        timeB.addTextChangedListener(textWatcher);
        dateB.addTextChangedListener(textWatcher);

        //add event button
        addB.setOnClickListener(view -> {

            //adding the event to the database
            MainDatabase db = new MainDatabase(CreateEvent.this);
            db.addData(
                    dateB.getText().toString().trim(),
                    timeB.getText().toString().trim(),
                    titleIN.getText().toString().trim(),
                    descriptionIN.getText().toString().trim()
            );
            finish();
        });
    }

    // Makes sure all text is filled in
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String date = dateB.getText().toString().trim();
            String time = timeB.getText().toString().trim();
            String title = titleIN.getText().toString().trim();
            String description = descriptionIN.getText().toString().trim();

            addB.setEnabled(!title.isEmpty() && !description.isEmpty() &&
                    !date.isEmpty() && !time.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {}
    };

    //date and time set
    private void selectTime() {
        Calendar cal = Calendar.getInstance();
        int hr = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        TimePickerDialog PickerDialog = new TimePickerDialog(this, (timePicker, i, i1) -> {
            notification = i + ":" + i1;
            timeB.setText(formatTime(i, i1));
        }, hr, min, false);
        PickerDialog.show();
    }

    private void selectDate() {
        Calendar cal = Calendar.getInstance();
        int Y = cal.get(Calendar.YEAR);
        int M = cal.get(Calendar.MONTH);
        int D = cal.get(Calendar.DAY_OF_MONTH);
        @SuppressLint("DefaultLocale") DatePickerDialog datePickerDialog = new DatePickerDialog(
                this, (datePicker, year, month, day) ->
                dateB.setText(String.format(
                        "%d-%d-%d", day, month + 1, year)),
                Y, M, D);
        datePickerDialog.show();
    }

    public String formatTime(int hr, int min) {

        String T;
        String RM;

        if (min / 10 == 0) {
            RM = "0" + min;
        } else {
            RM = "" + min;
        }

        //reading time
        if (hr == 0) {
            T = "12" + ":" + RM + " AM";
        } else if (hr < 12) {
            T = hr + ":" + RM + " AM";
        } else if (hr == 12) {
            T = "12" + ":" + RM + " PM";
        } else {
            int temp = hr - 12;
            T = temp + ":" + RM + " PM";
        }
        return T;
    }
}

