package com.example.mobile2appevent_trackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Signup extends AppCompatActivity {

    EditText username, password, confirmPassword;
    Button signUpBtn, alreadyHaveAnAccountBtn;
    LoginDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        username = (EditText) findViewById(R.id.emailOrUsername);
        password = (EditText) findViewById(R.id.password);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);

        signUpBtn = (Button)  findViewById(R.id.signUp);
        alreadyHaveAnAccountBtn = (Button) findViewById(R.id.alreadyHaveAnAccount);

        db = new LoginDatabase(this);

        //lets users register with their username and password
        signUpBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String confirmPass = confirmPassword.getText().toString();

                //checking for data
                if(user.equals("") || (pass.equals("") || confirmPass.equals("")))
                    Toast.makeText(Signup.this, "Please check all fields", Toast.LENGTH_SHORT).show();
                else{
                    //makes sure passwords are the same
                    if(pass.equals(confirmPass)){
                        //checks for username in the database
                        Boolean checkuser = db.checkUsername(user);
                        if(checkuser == false){
                            //puts the username and the password into the database
                            Boolean insert = db.insertData(user, pass);
                            //start the home
                            if(insert == true){
                                Toast.makeText(Signup.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), Events.class);
                                startActivity(intent);
                            }
                            else{
                                Toast.makeText(Signup.this, "User already exists", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(Signup.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(Signup.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //takes you to log in
        alreadyHaveAnAccountBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Main.class);
                startActivity(intent);
            }
        });
    }
}
