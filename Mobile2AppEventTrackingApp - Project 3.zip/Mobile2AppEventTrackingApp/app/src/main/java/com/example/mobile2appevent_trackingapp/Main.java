package com.example.mobile2appevent_trackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Main extends AppCompatActivity {


    EditText username, password;
    Button signUpBtn, logInBtn;

    LoginDatabase DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.emailOrUsername);
        password = (EditText) findViewById(R.id.password);
        logInBtn = (Button) findViewById(R.id.logInBtn);
        signUpBtn = (Button) findViewById(R.id.signUp);
        //smsRequestB = (Button) findViewById(R.id.smsRequestBtn);
        DB = new LoginDatabase(this);

        // Log in
        logInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String U = username.getText().toString();
                String P = password.getText().toString();

                //Makes sure all required fields are filled
                if (U.equals("") || P.equals("")) {
                    Toast.makeText(Main.this, "Make sure both fields are filled in", Toast.LENGTH_SHORT).show();
                }
                //This will look to see if the username and password already exist and to see if it is a match in the database
                else {
                    Boolean checkPass = DB.checkUsernamePassword(U, P);
                    if (checkPass) {
                        Toast.makeText(Main.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Events.class);
                        startActivity(intent);

                    } else {
                        Toast.makeText(Main.this, "Invalid credentials", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });

        //register and have user data stored in the database
        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Signup.class);
                startActivity(intent);
            }
        });
    }

}

